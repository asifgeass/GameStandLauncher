﻿namespace TouchHook
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate int ZoomGestureEventHandler(object sender, ZoomGestureEventArgs e);
}

