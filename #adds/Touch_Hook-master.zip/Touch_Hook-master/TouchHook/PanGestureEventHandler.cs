﻿namespace TouchHook
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate int PanGestureEventHandler(object sender, PanGestureEventArgs e);
}

