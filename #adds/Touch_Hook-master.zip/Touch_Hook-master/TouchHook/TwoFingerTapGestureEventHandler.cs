﻿namespace TouchHook
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate int TwoFingerTapGestureEventHandler(object sender, TwoFingerTapGestureEventArgs e);
}

