﻿namespace TouchHook
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate int RotateGestureEventHandler(object sender, RotateGestureEventArgs e);
}

