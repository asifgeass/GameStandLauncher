﻿namespace TouchHook
{
    using System;

    public class MouseEventArgs : EventArgs
    {
        public uint hitTestCode;
        public int x;
        public int y;
    }
}

