﻿namespace TouchHook
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate int PressAndTapGestureEventHandler(object sender, PressAndTapGestureEventArgs e);
}

