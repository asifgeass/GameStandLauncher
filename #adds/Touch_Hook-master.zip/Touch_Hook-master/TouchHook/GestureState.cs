﻿namespace TouchHook
{
    using System;

    public enum GestureState
    {
        Begin,
        Move,
        Inertia,
        End
    }
}

